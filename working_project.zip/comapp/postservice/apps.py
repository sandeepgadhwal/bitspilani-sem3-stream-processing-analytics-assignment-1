from django.apps import AppConfig


class PostserviceConfig(AppConfig):
    name = 'postservice'
