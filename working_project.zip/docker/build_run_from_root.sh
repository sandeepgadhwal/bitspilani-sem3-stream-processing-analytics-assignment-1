docker build -t spa-asgm -f ./docker/Dockerfile .
